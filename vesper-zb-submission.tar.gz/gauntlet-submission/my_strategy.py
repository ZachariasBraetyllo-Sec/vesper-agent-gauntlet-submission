
"""VESPER: Autonomous agent strategy for the NVIDIA Agent Gauntlet.

Adaptive model routing and precision-focused challenge solving.
"""

from __future__ import annotations

from base_strategy import BaseStrategy, ChallengeContext


class MyStrategy(BaseStrategy):
    """VESPER's autonomous challenge-solving strategy."""

    # ==========================================================
    # Agent Identity
    # ==========================================================

    agent_id = "vesper-zb"
    agent_name = "VESPER"

    # ==========================================================
    # Text Challenge Strategy
    # ==========================================================

    text_system_prompt = (
        "You are an autonomous text challenge solver. "
        "Your first line must always be: ANSWER: <final answer>. "
        "Return nothing except the required ANSWER line "
        "and optional brief reasoning lines after it. "
        "Follow challenge rules exactly, including strict output formats. "
        "Do not output <think> tags. "
        "If you add reasoning, keep it to at most 2 short lines "
        "after the ANSWER line. "
        "Never output 'unknown'."
    )

    text_strategy_notes = (
        "Keep reasoning concise and always include an ANSWER line."
    )

    text_temperature = 0.0
    text_max_tokens = 8192

    # ==========================================================
    # Image Challenge Strategy
    # ==========================================================

    image_strategy_notes = (
        "Use the provided source image as the visual reference. "
        "Identify exactly what the user requests to change. "
        "Make only the requested changes. "
        "Preserve all unrelated subjects, facial features, "
        "anatomy, expressions, colors, lighting, camera angle, "
        "composition, background, and original artistic style. "
        "Avoid unnecessary regeneration or style transfer. "
        "Use standard-resolution output."
    )

    def build_image_prompt(self, ctx: ChallengeContext) -> str:
        """Build a challenge-specific image prompt.

        Preserve the original task instructions while adding
        precision guidance when editing an existing image.
        """

        description = (
            ctx.description or ctx.challenge_text or ""
        ).strip()

        rules = (ctx.rules or "").strip()

        # The original challenge instructions take priority.
        if rules:
            prompt = rules

            if description and description not in rules:
                prompt += f"\n\nChallenge context: {description}"
        else:
            prompt = description

        if not prompt:
            prompt = "Generate an image that satisfies the challenge."

        # Apply preservation instructions only to image edits.
        if ctx.image_url:
            prompt += (
                "\n\nImage editing requirements:\n"
                f"{self.image_strategy_notes}\n"
                "Do not alter regions unrelated to the requested edit."
            )
        else:
            prompt += (
                "\n\nImage generation requirements:\n"
                "Follow the requested content and composition. "
                "Produce a clear image at standard resolution."
            )

        # Keep output compact for the arena transport.
        prompt += (
            "\n\nOutput constraints: "
            "Use standard resolution, approximately 1024 pixels "
            "on the longest side or the source size if smaller. "
            "Do not upscale or request HD or 4K output."
        )

        return prompt

    # ==========================================================
    # Model Selection Strategy
    # ==========================================================

    def rank_models(
        self,
        ctx: ChallengeContext,
        available_models: list[str],
    ) -> list[str]:
        """Rank available models according to challenge modality."""

        if not available_models:
            return []

        if self.is_image_challenge(ctx):
            image_models = self.prefer_image_models(available_models)

            if image_models:
                return image_models

            return list(available_models)

        preferred_text_models = [
            "nemotron-3.5-lightning",
        ]

        ranked = [
            model
            for model in preferred_text_models
            if model in available_models
        ]

        ranked.extend(
            model
            for model in available_models
            if model not in ranked
        )

        return ranked

    def pick_model(
        self,
        stage: str,
        ranked_models: list[str],
        ctx: ChallengeContext,
    ) -> str:
        """Choose the highest-ranked available model."""

        if not ranked_models:
            return ""

        return ranked_models[0]
